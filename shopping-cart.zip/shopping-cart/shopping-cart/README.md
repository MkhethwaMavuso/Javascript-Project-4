On this project I showcased my ability to build an online store 
using single page JS application. I did this project because online stores 
are big in the industry and I think this type of project might attract employers. 

(1) Defined the HTML structure for the shopping cart.
(2) Created an array or object to store products with details like ID, name, price, etc.
(3) Render products dynamically from the array onto the page.
(4) Implement logic to add products to the cart.
(5) Implement logic to clear the cart.
(6) Styled page using CSS to make it visually appealing and user-friendly.